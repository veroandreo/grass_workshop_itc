Data aggregated in GRASS 7 from http://www.ecad.eu/
                                European Climate Assessment & Dataset project

The map "ecad_solarangle_elev.tif" has been calculated from
elev_0.25deg_reg_v6.0.tif in GRASS 7.
